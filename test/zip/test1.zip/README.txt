This file is a sample zip file used by konCePCja tests.
